import { Calendar, Download, FileText, Edit3, Building2, Home as HomeIcon, Users, Phone, Mail, Award, School } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <School className="w-8 h-8 text-orange-500" />
              <div>
                <span className="text-xl font-bold text-blue-900">Education</span>
                <span className="text-xl font-bold text-orange-500">Malaysia</span>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-gray-700 hover:text-blue-600">Home</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Resources</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Courses</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Universities</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Specialization</a>
              <a href="#" className="text-gray-700 hover:text-blue-600">Scholarship</a>
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Get Started
              </button>
            </div>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
          <HomeIcon className="w-4 h-4" />
          <span>Home</span>
          <span>/</span>
          <span>Universities</span>
          <span>/</span>
          <span className="text-gray-900">International Islamic University of Malaysia</span>
        </div>

        {/* University Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-4">
              <img
                src="https://images.pexels.com/photos/267885/pexels-photo-267885.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
                alt="IIUM Logo"
                className="w-20 h-20 rounded-lg object-cover"
              />
              <div>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">
                  International Islamic University of Malaysia
                </h1>
                <div className="flex items-center space-x-4 text-sm">
                  <span className="text-blue-600">Location: Gombak Road, 53100 Gombak, Selangor</span>
                  <button className="text-blue-600 hover:text-blue-700">Get Direction</button>
                </div>
                <div className="flex items-center space-x-4 mt-2">
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">Public Institution</span>
                  <div className="flex items-center">
                    <span className="text-yellow-500">★★★</span>
                    <span className="text-gray-400">★★</span>
                    <span className="ml-2 text-sm text-gray-600">SETARA Ranking</span>
                  </div>
                  <span className="text-sm text-gray-600">Approved By: MQA</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Images Gallery */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="col-span-2 row-span-2 relative rounded-lg overflow-hidden">
            <img
              src="https://images.pexels.com/photos/1454360/pexels-photo-1454360.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="University Campus"
              className="w-full h-full object-cover"
            />
            <button className="absolute bottom-4 left-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              View All Photos
            </button>
          </div>
          <img
            src="https://images.pexels.com/photos/159490/yale-university-landscape-universities-schools-159490.jpeg?auto=compress&cs=tinysrgb&w=400"
            alt="Campus View 2"
            className="col-span-1 rounded-lg h-48 w-full object-cover"
          />
          <img
            src="https://images.pexels.com/photos/256490/pexels-photo-256490.jpeg?auto=compress&cs=tinysrgb&w=400"
            alt="Campus View 3"
            className="col-span-1 rounded-lg h-48 w-full object-cover"
          />
          <img
            src="https://images.pexels.com/photos/1438072/pexels-photo-1438072.jpeg?auto=compress&cs=tinysrgb&w=400"
            alt="Campus View 4"
            className="col-span-1 rounded-lg h-48 w-full object-cover"
          />
          <img
            src="https://images.pexels.com/photos/1595391/pexels-photo-1595391.jpeg?auto=compress&cs=tinysrgb&w=400"
            alt="Campus View 5"
            className="col-span-1 rounded-lg h-48 w-full object-cover"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Stats */}
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-white rounded-lg shadow-sm p-6 text-center">
                <Calendar className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">1970</div>
                <div className="text-sm text-gray-600">Established Year</div>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-6 text-center">
                <School className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">No</div>
                <div className="text-sm text-gray-600">Scholarship</div>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-6 text-center">
                <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">789</div>
                <div className="text-sm text-gray-600">Views</div>
              </div>
              <div className="bg-white rounded-lg shadow-sm p-6 text-center">
                <Building2 className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">N/A</div>
                <div className="text-sm text-gray-600">Courses</div>
              </div>
            </div>

            {/* Study Options */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Study Options</h2>
              <div className="flex flex-wrap gap-3">
                <div className="flex items-center space-x-2 bg-green-50 border border-green-200 rounded-lg px-4 py-2">
                  <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <span className="text-gray-700">Study Online</span>
                </div>
                <div className="flex items-center space-x-2 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2">
                  <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <span className="text-gray-700">Part Time</span>
                </div>
                <div className="flex items-center space-x-2 bg-purple-50 border border-purple-200 rounded-lg px-4 py-2">
                  <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">✓</span>
                  </div>
                  <span className="text-gray-700">Full Time</span>
                </div>
              </div>
            </div>

            {/* New Info Sections */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Accredited By */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Award className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Accredited By</h3>
                    <p className="text-gray-600">Malaysian Qualifications Agency (MQA)</p>
                    <p className="text-gray-600">Ministry of Higher Education</p>
                  </div>
                </div>
              </div>

              {/* Hostel Facility */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-start space-x-3">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <HomeIcon className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Hostel Facility</h3>
                    <p className="text-gray-600">On-campus accommodation available</p>
                    <p className="text-gray-600">Separate hostels for male and female students</p>
                  </div>
                </div>
              </div>

              {/* Total Students */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-start space-x-3">
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <Users className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Total Students</h3>
                    <p className="text-gray-600">23,000+ students</p>
                    <p className="text-gray-600">4,000+ international students</p>
                  </div>
                </div>
              </div>

              {/* Contact Info */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-start space-x-3">
                  <div className="bg-orange-100 p-3 rounded-lg">
                    <Phone className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Contact Info</h3>
                    <div className="flex items-center space-x-2 text-gray-600 mb-1">
                      <Phone className="w-4 h-4" />
                      <span>+603-6196-4000</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>info@iium.edu.my</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Facilities */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Facilities</h2>
              <div className="flex flex-wrap gap-3">
                <span className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg">Business Administration</span>
                <span className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg">Computer Science</span>
                <span className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg">Engineering</span>
                <span className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg">Arts & Sciences</span>
                <span className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg">Health Sciences</span>
                <span className="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg">Communications</span>
              </div>
            </div>

            {/* Overview */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4 border-l-4 border-blue-600 pl-4">Overview</h2>
              <img
                src="https://images.pexels.com/photos/1454360/pexels-photo-1454360.jpeg?auto=compress&cs=tinysrgb&w=800&h=400"
                alt="Overview"
                className="w-full rounded-lg mb-4"
              />
              <p className="text-gray-700 leading-relaxed">
                The International Islamic University Malaysia, also known as IIUM, is a public university in Malaysia.
                Headquartered in Gombak, Selangor, IIUM has six other campuses all over Malaysia: two medical-centric
                campuses and a Centre for Foundation Studies in Gambang, Pahang, two city campuses in Kuala Lumpur,
                and a language and tourism campus in Pagoh, Johor.
              </p>
            </div>
          </div>

          {/* Right Column - Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              {/* Download Brochure */}
              <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 mb-3">
                <Download className="w-5 h-5" />
                <span>Download Brochure</span>
              </button>

              {/* Book Counselling Session */}
              <button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 rounded-lg hover:from-orange-600 hover:to-orange-700 transition-colors flex items-center justify-center space-x-2 mb-3">
                <Calendar className="w-5 h-5" />
                <span>Book Counselling Session</span>
              </button>

              {/* Download Fees Structure */}
              <button className="w-full bg-white border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2 mb-3">
                <FileText className="w-5 h-5" />
                <span>Download Fees Structure</span>
              </button>

              {/* Write a Review */}
              <button className="w-full bg-white border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-2 mb-6">
                <Edit3 className="w-5 h-5" />
                <span>Write a review</span>
              </button>

              {/* Global Rankings */}
              <div className="mb-6">
                <h3 className="text-lg font-bold text-gray-900 mb-3">Global Rankings</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg p-4 text-white">
                    <div className="text-2xl font-bold">#133</div>
                    <div className="text-sm opacity-90">in World</div>
                  </div>
                  <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg p-4 text-white">
                    <div className="text-2xl font-bold">#181</div>
                    <div className="text-sm opacity-90">in Malaysia</div>
                  </div>
                </div>
                <button className="text-blue-600 text-sm mt-3 hover:text-blue-700">View ranking details →</button>
              </div>

              {/* Get In Touch Form */}
              <div className="border-t pt-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Mail className="w-6 h-6 text-blue-600" />
                  <h3 className="text-lg font-bold text-gray-900">Get In Touch</h3>
                </div>
                <form className="space-y-3">
                  <input
                    type="text"
                    placeholder="Full Name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <input
                    type="email"
                    placeholder="Email Address"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <div className="flex space-x-2">
                    <select className="w-24 px-2 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                      <option>+91</option>
                      <option>+60</option>
                      <option>+1</option>
                    </select>
                    <input
                      type="tel"
                      placeholder="Phone Number"
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option>Select program</option>
                    <option>Undergraduate</option>
                    <option>Postgraduate</option>
                    <option>Foundation</option>
                  </select>
                  <div className="flex items-center space-x-2 text-sm">
                    <input type="checkbox" className="w-4 h-4" />
                    <span className="text-gray-600">I agree to the Terms and Privacy Statement</span>
                  </div>
                  <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors">
                    Submit
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
